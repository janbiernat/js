﻿//JavaScript - Plik zewnętrzny. 
function mat_potega() { 
  var T = ""; T = document.getElementById('fkEdit').value; 
  if(T.trim() != "") { 
    /*Jeżeli wprowadzono liczbę w kontrolce/komponencie o nazwie "fkEdit", to 
      wykonaj poniższy kod. W przeciwnym przypadku wykonaj kod po słowie ELSE.*/ 
    var iWynik = 0; iWynik = Number(T)*Number(T); 
    document.getElementById('fkWynik').value = "Wynik działania wynosi: "+iWynik.toString(); 
  } else { document.getElementById('fkWynik').value = "Proszę wprowadzić liczbę!"; }  
    /* 
      "var T = "";" - Zadeklarowanie zmiennej tekstowej o nazwie "T". 
      "document.getElementById('fkEdit').value" - Pobranie danych wpisanych 
                                                  w kontrolce/komponencie 
                                                  o nazwie "fkEdit". 
      "T = document.getElementById('fkEdit').value;" - Przepisanie pobranych danych 
                                                       (z kontrolki/komponentu o nazwie "fkEdit") 
                                                       do zmiennej tekstowej o nazwie "T". 
      "var iWynik = 0;" - Zadeklarowanie zmiennej liczbowej o nazwie "iWynik". 
      "Number(T)" - Zamiana tekstu zawierającego tylko cyfry na liczbę 
                    (na której można wykonywać działania arytmetyczne). 
      "Number(T)*Number(T);" - Wykonanie mnożenia tej samej liczby, która została pobrana 
                               z kontrolki/komponentu o nazwie "fkEdit". 
      "iWynik = Number(T)*Number(T);" - Przypisanie do zmiennej liczbowej o nazwie "iWynik" 
                                        wyniku z mnożenia dwóch tych samych liczb. 
      "iWynik.toString();" - Zamiana liczby na ciąg znaków zawierających wynik z mnożenia 
                             (czyli ciąg znaków zawierający tylko cyfry). 
      "Wynik działania wynosi: "+iWynik.toString();" - łączenie ciągów znaków 
                                                       (czyli połączenie tekstu zawartego 
                                                       pomiędzy cudzysłowami z ciągiem znaków 
                                                       zawierających wynik z mnożenia tej samej liczby). 
      "document.getElementById('fkWynik').value = "Wynik działania wynosi: "+iWynik.toString();" - Przypisanie połączonych ciągów znaków do kontrolki/komponentu o nazwie "fkWynik". 
    */ 
} 
function DataCzas() { 
  //DataCzas - Funkcja wyświetla bieżącą datę i czas na podstawie zegara systemowego. 
    //Deklaracja zmiennych. 
      var Teraz = new Date(); //Utworzenie obiektu TERAZ na podstawie konstruktora DATE(). 
      var Dzien = Teraz.getDate();      //Podaje nr dnia w miesiącu (z zakresu od 1 do 31). 
      var Miesiac = Teraz.getMonth()+1; //Podaje aktualny nr miesiąca licząc od 0 (0 - styczeń, 1 - luty itp.). 
      var Rok = Teraz.getFullYear();    //Podaje aktualny nr roku (np. 1999 lub 2000). 
      var Godzina = Teraz.getHours();   //Podaje aktualną godzinę (z zakresu od 0 do 23). 
      var Minuta = Teraz.getMinutes();  //Podaje aktualną minutę (z zakresu od 0 do 59). 
      var Sekunda = Teraz.getSeconds(); //Podaje aktualną sekundę (z zakresu od 0 do 59). 
    //Formatowanie daty. 
      if(Miesiac < 10) { Miesiac = "0"+Miesiac; } 
      if(Dzien < 10) { Dzien = "0"+Dzien; } 
    //Formatowanie godziny. 
      if(Godzina < 10) { Godzina = "0"+Godzina; } 
      if(Minuta < 10) { Minuta = "0"+Minuta; } 
      if(Sekunda < 10) { Sekunda = "0"+Sekunda; } 
    //Wyświetlenie daty i czasu. 
      document.getElementById("Zegar").innerHTML = Rok+"-"+Miesiac+"-"+Dzien+" / "+Godzina+":"+Minuta+"."+Sekunda; 
      setTimeout("DataCzas()", 1000); //Wyświetlenie daty i czasu co sekundę. Jest to zdarzenie. 
} 